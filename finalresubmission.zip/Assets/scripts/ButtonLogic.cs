using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;


public class ButtonLogic : MonoBehaviour
{
    
    private long playerScore =0;
    private int leftItem = 0;
    private int rightItem = 0;
    private int result = 0;
    private int yeast = 100;
    private int water = 100;
    public Text playerTextScore, textyest, textwater;
    public Image left, right, sprit;
    public Sprite h1, h2, h3, w1, w2, w3, b1, b2, b3, wi1, wi2, wi3, d;

    
    // Start is called before the first frame update
    void Start()
    {
        updateImages();
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Application.platform == RuntimePlatform.Android)
        {

            // Check if Back was pressed this frame
            if (Input.GetKeyDown(KeyCode.Escape))
            {

                SceneManager.LoadScene(0);
            }
        }


    }
    public void back()
    {
        SceneManager.LoadScene(0);
    }

    public void updateImages() // updates the ui
    {
        string part1 = "$ ";
        long temp1 = playerScore;
        string part3 = " ";
        string part4 = part1 + temp1 + part3;
        playerTextScore.text = part4;
        string bot = "100";
        string mid = "/\n";
        textwater.text = water + "\n" + mid + bot;
        textyest.text = yeast + "\n" + mid + bot;



        switch (leftItem)
        {
            case 1:
                left.sprite = w1;
                break;
            case 2:
                left.sprite = w2;
                break;
            case 3:
                left.sprite = w3;
                break;
            case 4:
                left.sprite = h1;
                break;
            case 5:
                left.sprite = h2;
                break;
            case 6:
                left.sprite = h3;
                break;
            default:
                left.sprite = d;
                break;


        }

        switch (rightItem)
        {
            case 1:
                right.sprite = w1;
                break;
            case 2:
                right.sprite = w2;
                break;
            case 3:
                right.sprite = w3;
                break;
            case 4:
                right.sprite = h1;
                break;
            case 5:
                right.sprite = h2;
                break;
            case 6:
                right.sprite = h3;
                break;
            default:
                right.sprite = d;
                break;


        }
        switch (result)
        {
            case 1:
                sprit.sprite = b1;
                break;
            case 2:
                sprit.sprite = b2;
                break;
            case 3:
                sprit.sprite = b3;
                break;
            case 4:
                sprit.sprite = wi1;
                break;
            case 5:
                sprit.sprite = wi2;
                break;
            case 6:
                sprit.sprite = wi3;
                break;
            default:
                sprit.sprite = d;
                break;
        }





    }

    public void removeitem(int item) // removes item from use
    {
        if(item == 1)
        {
            leftItem = 0;
            updateImages();
        }
        else
        {
            rightItem = 0;
            updateImages();
        }
     


    }


 

    public void pressedingredient(int i) // determines what section needs to be changed to the indicated type of ingredient
    {
        
        if (leftItem == 0)
        {
            leftItem = i;
            updateImages();

        }
        else if (rightItem == 0)
        {
            rightItem = i;
            updateImages();
        }
   



    }
    public void determinRestult() // this functions determines what sprite was created
    {
        if(result != 0)
        {
            return;
        }
        bool waschanged = false;
        Random.InitState(System.DateTime.Now.Millisecond); 
        int ra;
        if(leftItem != 0 && rightItem != 0)// both 
        {
            if( leftItem >= 4 && rightItem >= 4)
            {
                return;
            }
            if(leftItem == rightItem) // rand of if both are wheat
            {
                switch (leftItem) 
                {
                    case 1:
                        waschanged = true;
                        ra = Random.Range(1, 2);
                        if (ra == 1) result = 4;
                        if (ra == 2) result = 5;
                        break;
                    case 2:
                        waschanged = true;
                        ra = Random.Range(1, 2);
                        if (ra == 1) result = 5;
                        if (ra == 2) result = 6;

                        break;
                    case 3:
                        waschanged = true;
                        result = 6;
                        break;
                }
            }
            else if (leftItem <= 3 && rightItem <= 3)
            {
                waschanged = true;
                if (leftItem == 1 && rightItem == 2)
                {
                    result = 4;
                }
                else if ( leftItem == 1 && rightItem ==3)
                {
                    result = 5;
                }
                if (leftItem == 2 && rightItem == 1)
                {
                    result = 4;
                }
                else if (leftItem == 2 && rightItem == 3)
                {
                    result = 6;
                }
                if (leftItem == 3 && rightItem == 2)
                {
                    result = 6;
                }
                else if (leftItem == 3 && rightItem == 1)
                {
                    result = 4;
                }
            }
            else
            {
                if(leftItem <= 3) //wheat on left
                {
                    waschanged = true;
                    if (leftItem == 1 && rightItem == 4)
                    {
                        result = 1;

                    }
                    else if (leftItem == 1 && rightItem == 5)
                    {
                        Debug.Log("beer 1 should show up");
                        result = 1;
                    }
                    else if (leftItem == 1 && rightItem == 6)
                    {
                        result = 2;
                    }
                    else if (leftItem == 2 && rightItem == 4)
                    {
                        result = 2;

                    }
                    else if (leftItem == 2 && rightItem == 5)
                    {
                        result = 2;
                    }
                    else if (leftItem == 2 && rightItem == 6)
                    {
                        result = 3;
                    }
                    else if (leftItem == 3 && rightItem == 4)
                    {
                        result = 3;
                    }
                    else if (leftItem == 3 && rightItem == 5)
                    {
                        result = 3;
                    }
                    else if (leftItem == 3 && rightItem == 6)
                    {
                        result = 3;
                    }
                }
                else if(leftItem >= 4) // still beer but with hops on leftsizd
                {
                    waschanged = true;
                    if (leftItem == 4 && rightItem == 1)
                    {
                        result = 1;

                    }
                    else if (leftItem == 5 && rightItem == 1)
                    {
                        result = 1;
                    }
                    else if (leftItem == 6 && rightItem == 1)
                    {
                        result = 2;
                    }
                    else if (leftItem == 4 && rightItem == 2)
                    {
                        result = 2;

                    }
                    else if (leftItem == 5 && rightItem == 2)
                    {
                        result = 2;
                    }
                    else if (leftItem == 6 && rightItem == 2)
                    {
                        result = 3;
                    }
                    else if (leftItem == 4 && rightItem ==3)
                    {
                        result = 3;
                    }
                    else if (leftItem == 5 && rightItem == 3)
                    {
                        result = 3;
                    }
                    else if (leftItem == 6 && rightItem == 3)
                    {
                        result = 3;
                    }

                }

            }
        }
        else if(leftItem != 0) // left only
        {
            if(leftItem>= 4)
            {
                return;
            }
            waschanged = true;
            switch (leftItem)
            {
                case 1:
                    result = 4;
                    break;
                case 2:
                    result = 5;
                    break;
                case 3:
                    result = 6;
                    break;

            }
        }
        else // right only
        {
            if (rightItem >= 4)
            {
                return;
            }
            waschanged = true;
            switch (rightItem)
            {
                case 1:
                    result = 4;
                    break;
                case 2:
                    result = 5;
                    break;
                case 3:
                    result = 6;
                    break;

            }

        }
        
        if (waschanged)
        {
            leftItem = 0;
            rightItem = 0;
        }
        updateImages();



    }
    public void figureoutmoney()
    {

        switch (result)
        {
            case 1:
                playerScore += 10;
                break;
            case 2:
                playerScore += 30;
                break;
            case 3:
                playerScore += 50;
                break;
            case 4:
                playerScore += 50;
                break;
            case 5:
                playerScore += 100;
                break;
            case 6:
                playerScore += 150;
                break;
        }
        result = 0;
        updateImages();

    }
    public void sellbuttonpressed()
    {
        if(result == 0)
        {
            return;
        }
        else
        {
            figureoutmoney();
        }
    }
    public void pressedbuywaterbutton()
    {
        if(water < 100)
        {
            water += 5;
            playerScore -= 1;
            updateImages();
        }
    }
        
    public void pressedbuyyeastbutton()
    {
        if ( yeast < 100)
        {
            yeast += 5;
            playerScore -= 1;
            updateImages();

        }
        
    }


    public void pressedbrewbutton()
    {
        if(result != 0)
        {
            return;
        }
       if(leftItem!=0 || rightItem != 0)
        {
            if(yeast >=20 && water >= 20)
            {
                yeast -= 20;
                water -= 20;
                determinRestult();
            }
            
        }
        
        
    }

}
